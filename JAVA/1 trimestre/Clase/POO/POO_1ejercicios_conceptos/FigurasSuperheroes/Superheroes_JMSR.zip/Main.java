package POO.POO_1ejercicios_conceptos.FigurasSuperheroes;

public class Main {
    public static void main(String[] args) {
        Superheroe ironman = new Superheroe("Tony Stark");
        Dimension small = new Dimension(15, 5, 2);
        Figura = new Figura("AB205", 255, ironman, small);
        
    }
}
